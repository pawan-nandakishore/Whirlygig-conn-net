#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 20 13:35:09 2017

@author: pawan
"""

import json
import numpy as np

#
filename = 'instances_val2014.json'

from pprint import pprint

with open('instances_val2014.json') as data_file:
    data = json.load(data_file)

pprint(data)

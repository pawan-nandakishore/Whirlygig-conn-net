import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
import matplotlib.patches as patches
import json
import generate_squares as gs
import random 
import dict2xml
from xml.etree import ElementTree

limits = {'xo':10, 'yo':10, 'xm':290, 'ym':290}


large_center_limits = [ 50,220]
large_side_range =[20, 40]

#------------MYENCODER CLASS----------------#                                                     
class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)

#------------RANDOM LARGE SQUARE----------------#                                                     

def random_large_square(number_squares ): 
	
	for x in range(0,number_squares): 

		x_pos = random.randint(large_center_limits[0], large_center_limits[1])
		y_pos = random.randint(large_center_limits[0], large_center_limits[1])
		side = random.randint(large_side_range[0], large_side_range[1])

		x_pos_min_max_diff = [ x_pos - limits['xo'],  limits['xm'] - x_pos] 

		y_pos_min_max_diff = [  y_pos - limits['yo'],  limits['ym'] - y_pos] 
		    

		if(side> np.min(x_pos_min_max_diff)): 
			 
			final_side = np.min(x_pos_min_max_diff)

		elif((side> np.min(x_pos_min_max_diff)) &  (np.min(x_pos_min_max_diff)<10)):
        	
			final_side =10 

		elif(side<= np.min(x_pos_min_max_diff)): 
			
			final_side = side
		
	 
	print('starting position:', [x_pos,y_pos])
	print('side length:', final_side)
	print('x_lengths:', x_pos+final_side, np.abs(x_pos-final_side) )
	print('y_lengths:', y_pos+final_side, np.abs(y_pos-final_side) )
	print('y_pos_min_max_diff', y_pos_min_max_diff,'x_pos_min_max_diff ', x_pos_min_max_diff )
	
	
	return([x_pos,y_pos], final_side)



def random_small_square(square_center,side_value): 

	
	# four regions where points can sit 
	distance = 5 

	# Region 1  

	x_points = np.linspace(square_center[0] - side_value, square_center[0] + side_value-distance,distance+1, dtype='int') 
	y_points = np.linspace(square_center[1] - side_value, square_center[1] + side_value,distance+1, dtype='int') 



	# Region 2

	x2_points = np.linspace(square_center[0] - side_value, square_center[0] + side_value,distance+1, dtype='int') 
	y2_points = np.linspace(square_center[1] - side_value, square_center[1] -side_value-distance,distance+1, dtype='int') 



	# Region 3 
	x3_points = np.linspace(square_center[0] - side_value, square_center[0] + side_value,distance+1, dtype='int') 
	y3_points = np.linspace(square_center[1] + side_value- distance, square_center[1] + side_value,distance+1, dtype='int') 


	# Region 3 
	x4_points = np.linspace(square_center[0] + side_value, square_center[0] + side_value-distance,distance+1, dtype='int') 
	y4_points = np.linspace(square_center[1] - side_value- distance, square_center[1] + side_value,distance+1, dtype='int') 


	random_region = random.randint(1,4)

	if(random_region ==1): 
		x_pos_small  = random.sample(x_points, 1) 
		y_pos_small  = random.sample(y_points, 1) 

	elif(random_region ==2): 
		x_pos_small  = random.sample(x2_points, 1) 
		y_pos_small  = random.sample(y2_points, 1) 

	elif(random_region ==3): 
		x_pos_small  = random.sample(x3_points, 1) 
		y_pos_small  = random.sample(y3_points, 1) 

	elif(random_region ==4): 
		x_pos_small  = random.sample(x4_points, 1) 
		y_pos_small  = random.sample(y4_points, 1) 


	small_side_range =[20, 50]
	small_final_side = random.randint(small_side_range[0], small_side_range[1])
	small_square_position = [ x_pos_small[0]-small_final_side , y_pos_small[0]-small_final_side]  
	large_square_position = [square_center[0] -side_value,square_center[1] -side_value  ]
	print(small_square_position, large_square_position)

	return(small_square_position,large_square_position,small_final_side)	

###########################################################################################################
###########################################################################################################


number_of_images= 100
for i in range(0,number_of_images):

	grey_mask_name = 'grey_mask/grey_mask_'+str(i)+'.png'
	final_image_name = 'labeled_images/final_image_name'+str(i)+'.png'  

	square_center, large_final_side = random_large_square(1)
	small_square_position, large_square_position, small_final_side = random_small_square(square_center, large_final_side)

	small_mask, large_mask, total_mask = gs.square_image_generator(small_final_side*2, large_final_side*2, small_square_position,
	                                              
	                                                            large_square_position, grey_mask_name, final_image_name)
	


	x, y = gs.get_square(small_final_side, small_square_position)
	bbox_small= [x, y ]

	x2, y2 = gs.get_square(large_final_side, large_square_position)
	bbox_large= [x2, y2 ]

################################################################################################################
#..........................XML GENERATE.......................................................##################

	size = {'width': 300 , 'height': 300  , 'depth': 3 }
	
	small_square_dict = {'bbox':bbox_small }
	large_square_dict = {'bbox':bbox_large }

	squares = {'small_square': small_square_dict    ,'large_square': large_square_dict     }
	segmented = {'object':squares  }

	size = {'height': 300, 'width': 300}
	folder2 = 'VOC2012'
	annotation = {'folder':folder2  , 'filename': grey_mask_name, 'size':size , 'segmented': segmented     }
	

	root = dict2xml.ConvertDictToXml(annotation)

	tree = ElementTree.ElementTree(root)
	tree.write('xml_files/grey_mask_'+str(i)+'.xml')

################################################################################################################
#..........................JSON GENERATE.......................................................##################





	small_square_annots = {'area': small_final_side*small_final_side, 'bbox': [x,y]}
	
	
	large_square_annots = {'area': large_final_side*large_final_side, 'bbox': [x2,y2]}
	

	folder_loc = '/media/pawan/0B6F079E0B6F079E/PYTHON_SCRIPTS/Data science challenges/learning_tensorflow_local/more_codes/Test_mask_rcnn/'
	file1_name = grey_mask_name
	full_image = {'width': 300, 'height': 300, 'file_name': grey_mask_name}





	small_square =  { 'name': 'small_square' , 'supercategory': 'squares'} 
	large_square =  { 'name': ' large_square'  , 'supercategory': 'squares'} 

	dataset = {'annotations': [small_square_annots, large_square_annots], 'images': [full_image],
	           'categories': [small_square, large_square]}

	json_name ='json_files/grey_mask_'+str(i)+'.json' 	


	with open(json_name, 'w') as fp:
	    json.dump(dataset, fp, cls=MyEncoder)


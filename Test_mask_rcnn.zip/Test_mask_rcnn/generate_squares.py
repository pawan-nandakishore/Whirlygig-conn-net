#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 11:50:35 2017

@author: pawan
"""

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
import matplotlib.patches as patches
import json


plt.close()

#------------MYENCODER CLASS----------------#                                                     
class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)

#----------GET SQUARE ---------------# 
def get_square(side, edge_pts):
    """ generates a square of a given side and bottom left points xo,yo
    
    Args:
        side : float side length of a square
        edge_pts : float   bottom left x and y values 
               
    Returns:
        x: float  array shape(4,1) x values of verticies of a square  
        y: float  array shape(4,1) y values of verticies of a square
        
    """

    xo = edge_pts[0]
    yo = edge_pts[1]

    x = []
    y = []
    x3 = xo + side
    y3 = yo

    x1 = xo
    y1 = yo + side

    x2 = xo + side
    y2 = yo + side

    x = [xo, x1, x2, x3]
    y = [yo, y1, y2, y3]

    x = np.array(x)
    y = np.array(y)

    return (x, y)

#----------- CREATE TUPLE LIST---------------#
def create_tuple_list(x_list, y_list):
    """ make a list of tuples from the x and y positions of the vertices of a square 
    
    Args:
        x_list : float list of x coordinates for a square
        y_list : float   list of y coordinates for a square
               
    Returns:
        tuple_list: float  list of tuples where each tuple is an x and y coordinate
                            exampele [(xo,yo), (x1,y1), (x2,y2)]
    """

    xylist = np.array([x_list, y_list])
    xylist = tuple(xylist)

    tuple_list = []
    for i in range(0, x_list.shape[0]):
        tuple_list.append(tuple((x_list[i], y_list[i])))

    return (tuple_list)

#---------------GENERATE MASK --------#
def generate_mask(canvas_size, polygon, show_mask=True):
    """ given a canvas_size convert a polygon to a mask 
    
    Args:
        
        canvas_size : int  shape array [x,y]  contains size of the background 
        polgon      : ints shape list of tuplese  coordinates of a polygon  
        
    Returns:
        
        mask        :  int array  returns a mask on the image of the size [canvas_size, canvas_size]
                                  the size of the mask is determined by the points in polygon 
        
    """

    img = Image.new('L', (canvas_size, canvas_size), 0)
    ImageDraw.Draw(img).polygon(polygon, outline=1, fill=1)
    mask = np.array(img)
    if (show_mask == True):
        plt.imshow(mask)
        plt.axis([0, canvas_size, 0, canvas_size])
        plt.show()

    return (mask)

#-------------CONVERT MASK TO RGB-----------#
def convert_mask_to_rgb(mask, rgb_val):
    """ convert a mask to an rgb image 
    
    Args:
        
        mask        :  int array  binary mask
        rgb_val     :  int array  rgb values, select color for each mask on the basis of these values 
        
    Returns:
        
        img2        :  int array  return an rgb image 
        
    """

    rgb_image = np.zeros([mask.shape[0], mask.shape[1], 3], 'uint8')

    for i in range(0, 3):
        mask_x, mask_y = np.where(mask == 1)
        rgb_image[mask_x, mask_y, i] = rgb_val[i]

    img2 = Image.fromarray(rgb_image)
    img2 = np.array(img2)

    return (img2)

#---------- GENERATE LARGE MASK-----------#
def generate_large_mask(mask, mask2, rgb_value):
    """  create an overlap of mask2 over mask 
    
    Args:
        
        mask        :  int array shape [:,:,3] rgb image    
        mask2       :  int array shape [:,:,3] rgb image
        
    Returns:
        
        mask        :  int array shape [:,:,3] rgb image   
        rgb_value   :  int array shape [r,g,b] rgb color 
        
    """

    large_x, large_y = np.where(mask2 == 1)
    for i in range(0, 3):
        mask[large_x, large_y, i] = rgb_value[i]
    return (mask)

#------- GET TUPLES LIST-------------#
def get_tuples_list(s_square_size, l_square_size, s_square_start, l_square_start):
    """ convert polygon coordinates into a list of tuples 
    
    Args:
        
      s_square_size :  int scalar side length of the small square     
      l_square_size :  int scalar side length of the large square 
      s_square_start:  int array  shape[2,1] x,y coordinates of the bottom left pt of small square
      l_square_start:  int array  shape[2,1] x,y coordinates of the bottom left pt of large square  
    Returns:
        
      s_square_list :  int tuples list of vertices of the small square 
      l_square_list :  int tuples list of vertices of the large square
        
    """

    # generate the x y positions for both the small square and the large square
    small_square_x, small_square_y = get_square(s_square_size, s_square_start)
    large_square_x, large_square_y = get_square(l_square_size, l_square_start)

    # make a list of tuples that will be fed into the generate mask function in order to 
    s_square_list = create_tuple_list(small_square_x, small_square_y)
    l_square_list = create_tuple_list(large_square_x, large_square_y)

    return (s_square_list, l_square_list)

#--------- PLOT BOUNDUNG BOX---------# 
def plot_bounding_box(rgb_mask, start_pt, side, start_pt2, side2,final_image_name):
    """plot bounding boxes on masks for the final image
    
    Args:
        
        rgb_mask        :  int array shape [:,:,3] rgb image    
        start_pt        :  int array shape [1,2] starting point for the first bounding box  
        side            :  int scalar            side length of the first bounding box 
        start_pt2       :  int array shape [1,2] starting point for the second bounding box
        side2           :  int scalar            side length of the first bounding box 
        
        
    Returns:
        
        None        :  plot the image rgb_mask and plot two bounding boxes, one for each square   
        
    """

    fig2 = plt.figure()
    ax2 = fig2.add_subplot(111)
    ax2.axis('off')
    ax2.imshow(rgb_mask)
    ax2.add_patch(
        patches.Rectangle(
            (start_pt[0], start_pt[1]),
            side,
            side,
            fill=False,
            edgecolor="y",  # remove background,
            linewidth=3
        )
    )

    ax2.imshow(rgb_mask)
    ax2.add_patch(
        patches.Rectangle(
            (start_pt2[0], start_pt2[1]),
            side2,
            side2,
            fill=False,
            edgecolor="y",  # remove background,
            linewidth=3
        )
    )

    plt.axis([0, 300, 300, 0])
    # plt.show()
    fig2.savefig(final_image_name)


#------- GENERATE COMBINED MASK -----------# 
def generate_combined_mask(mask, mask2, grey_mask_name):
    """plot bounding boxes on masks for the final image
    
    Args:
        
        mask        :  int array shape [rows, columns] binary image with 1s as mask and 0s as background    
        mask2       :  int array shape [rows, columns] binary image with 1s as mask and 0s as background 
        
    Returns:
        
        mask        :  int array shape [rows, columns] binary image with 1s as mask and 0s as background
    """

    mask[np.where(mask2 == 1)] = 1

    plt.imsave(grey_mask_name, mask)

    return mask





#---------- GET PIXEL LIST-------# 
def get_pixel_list(side, square_start_pt): 
    
    square_x, square_y = get_square(side,square_start_pt)
    square_xy = np.array([square_x,square_y])
    square_xy = square_xy.T
    square_xy = square_xy.reshape([square_xy.shape[0]*2])
    square_xy  = list(square_xy)
    return(square_xy) 

#--------------- SQUARE IMAGE GENERATOR---------# 
def square_image_generator(s_square_size, l_square_size, s_square_start, l_square_start,grey_mask_name, final_image_name):
    """ convert polygon coordinates into a list of tuples
    
    Args:
        
      s_square_size :  int scalar side length of the small square     
      l_square_size :  int scalar side length of the large square 
      s_square_start:  int array  shape[2,1] x,y coordinates of the bottom left pt of small square
      l_square_start:  int array  shape[2,1] x,y coordinates of the bottom left pt of large square  
    
    Returns:
        
      small_mask    :  int array shape [rows, columns] binary image with 1s as mask and 0s as background
      large_mask    :  int array shape [rows, columns] binary image with 1s as mask and 0s as background
      total_mask    :  int array shape [rows, columns] binary image with 1s as mask and 0s as background
        
    """



    grey_mask_name = grey_mask_name  
    final_image_name = final_image_name 
    # get a list of points for each square, big and small 
    small_square_list, large_square_list = get_tuples_list(s_square_size, l_square_size, s_square_start, l_square_start)

    canvas_size = 300

    # generate small and large mask 
    # both these masks are on a canvas which is of size [canvas_size, canvas_size]
    small_mask = generate_mask(canvas_size, small_square_list, show_mask=False)
    large_mask = generate_mask(canvas_size, large_square_list, show_mask=False)

    # get a combined mask of two squares 
    total_mask = generate_combined_mask(small_mask, large_mask,grey_mask_name)

#    plt.imshow(total_mask)
#    plt.show()
#    plt.savefig('mask_image.png')
    rgb_val1 = [50, 100, 250]
    rgb_val2 = [225, 25, 15]

    # generate small and large mask 
    small_color_mask = convert_mask_to_rgb(small_mask, rgb_val1)
  

    # get the final labeled image 
    final_labeled_image = generate_large_mask(small_color_mask, large_mask, rgb_val2)

    # get bounding boxes
    bbox_small_mask_x, bbox_small_mask_y = get_square(s_square_size, s_square_start)
    bbox_large_mask_x, bbox_large_mask_y = get_square(l_square_size, l_square_start)

    # plot bounding boxes
    plot_bounding_box(final_labeled_image, s_square_start, s_square_size, l_square_start, l_square_size,final_image_name)

    return (small_mask, large_mask, total_mask)



if __name__ == "__main__":

	###############################################################################
	##############     GENERATING SQUARES      ####################################
	###############################################################################
	# Base values
	small_square_start = [100, 100]
	large_square_start = [120, 120]
	small_square_size = 50
	large_square_size = 120
	canvas_size = 300

	small_square_start2 = [150, 50]
	large_square_start2 = [75, 75]
	small_square_size2 = 50
	large_square_size2 = 160


	small_square_start3 = [50, 150]
	large_square_start3 = [75, 75]
	small_square_size3 = 70
	large_square_size3 = 100





	grey_mask_name = 'grey_mask_1.png'
	final_image_name = 'final_image_name1.png'  

	small_mask1, large_mask1, total_mask1 = square_image_generator(small_square_size, large_square_size, small_square_start,
	                                                            large_square_start)


	grey_mask_name = 'grey_mask_2.png'
	final_image_name = 'final_image_name2.png'  


	small_mask2, large_mask2, total_mask2 = square_image_generator(small_square_size2, large_square_size2, small_square_start2,
	                                                            large_square_start2)




	grey_mask_name = 'grey_mask_3.png'
	final_image_name = 'final_image_name3.png'  


	small_mask3, large_mask3, total_mask3 = square_image_generator(small_square_size3, large_square_size3, small_square_start3,
	                                                            large_square_start3)

	###############################################################################
	##############    WRITING JSON FILES      ####################################
	###############################################################################





	##### SMALL MASK ANNOTATIONS ##############
	small_mask_area = small_mask1.shape[0] * small_mask1.shape[1]
	small_bounding_box = [small_square_start[0], small_square_start[1], small_square_size, small_square_size]
	small_category_id = 1
	small_just_id = 1
	small_img_id = 1
	small_iscrowd = 0
	small_segmentation = list(get_pixel_list(small_square_size, small_square_start))

	##### LARGE MASK ANNOTATIONS ##############
	large_mask_area = large_mask1.shape[0] * large_mask1.shape[1]
	large_bounding_box = [large_square_start[0], large_square_start[1], large_square_size, large_square_size]
	large_just_id = 2
	large_img_id = 1
	large_category_id = 1
	large_iscrowd = 0
	large_segmentation = list(get_pixel_list(large_square_size, large_square_start))




	######## DICTIONARY ################


	small_square_annots = {'area': small_mask_area, 'bbox': small_bounding_box, 'category_id': small_category_id,
	                       'id': small_just_id, 'image_id': small_img_id, 'iscrowd': small_iscrowd,
	                       'segmentation': [small_segmentation]}

	large_square_annots = {'area': large_mask_area, 'bbox': large_bounding_box, 'category_id': large_category_id,
	                       'id': large_just_id, 'image_id': large_img_id, 'iscrowd': large_iscrowd,
	                       'segmentation': [large_segmentation]}


	folder_loc = '/media/pawan/0B6F079E0B6F079E/PYTHON_SCRIPTS/Data science challenges/learning_tensorflow_local/more_codes/Test_mask_rcnn/'
	file1_name = 'grey_mask_1.png'

	full_image = {'id': 1, 'image_id': 1, 'width': canvas_size, 'height': canvas_size, 'file_name': 'trial_image.png', 'license': 5,
	              'flickr_url': 'none', 'file_loc': folder_loc+file1_name, 'data_captured': 'none '}





	small_square =  {'id': 1, 'name': 'small_square' , 'supercategory': 'squares'} 
	large_square =  {'id': 2, 'name': ' large_square'  , 'supercategory': 'squares'} 

	dataset = {'annotations': [small_square_annots, large_square_annots], 'images': [full_image],
	           'categories': [small_square, large_square]}


	with open('data.json', 'w') as fp:
	    json.dump(dataset, fp, cls=MyEncoder)


	plt.close()




#def get_pixel_list(mask):
#    """ Get a flattened list of pixels which represent mask location in the image 
#    
#    Args:
#        
#        mask        :  int array shape [rows, columns] binary image with 1s as mask and 0s as background    
#        
#    Returns:
#        
#        pixel_list  :  int array shape [N, 1] reshaped list of pixels where [[xo,x1,...],[yo,y1,...] ] is [xo,yo,x1,y1,....]
#    """
#    
#    mask_locs = np.where(mask == 1)
#    
#    mask_locs = np.array(mask_locs)
#    mask_locs = mask_locs.T
#    
#    pixel_list = mask_locs.reshape([mask_locs.shape[0] * 2])
#    pixel_list_paired = pixel_list.reshape((int(len(pixel_list) / 2), 2))
#
#    np.testing.assert_array_equal(pixel_list_paired, mask_locs, ' error nahi chal raha hai')
#
#
#
#    
#
#    return pixel_list